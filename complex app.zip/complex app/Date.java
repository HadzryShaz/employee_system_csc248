/*
   //CLASS EMPLOYEE
   public class Employee2 {
    
    private String empName,empID,empEmail,empDpmt,empStat;
    private Address empAlamat;
    private Date empTarikh;
    private Double empBasic, empAllow;
    private Date tarikh;
    private int empLeave ;
    private double fullSalary, allowance, subLeave;

    
    
    public Employee2(String n, String i, String e, String s1, String s2, String pc, String dt, String st, int dey, int month, int yer, String d, String s, int l)
    {
        
        empName = n;
        empID = i;
        empEmail = e;
        empAlamat = new Address(s1,s2,pc,dt,st);
        empTarikh = new Date(dey,month,yer);
        empDpmt = d;
        empStat = s;
        empLeave = l;
        
    }
    
    
    public void setEmployee2(String n, String i, String e, String s1, String s2, String pc, String dt, String st, int day, int month, int year, String d, String s, int l)
    {      
        empName = n;
        empID = i;
        empEmail = e;
        empAlamat = new Address(s1,s2,pc,dt,st);
        empTarikh = new Date(day,month,year);
        empDpmt = d;
        empStat = s;
        empLeave = l;
        
        
        
    }
    
    public String getName() { return empName; }
    public String getID() { return empID; }
    public String getEmail() { return empEmail; }
    public Address getAlamat() { return empAlamat; }
    public Date getTarikh() { return empTarikh; }
    public String getDpmt() { return empDpmt; }
    public String getStat() { return empStat; }
    public int getLeave()   { return empLeave; }
    
    public String toString(){
        return "\n\t\t|Name : "+ empName + "\n\t\t|ID : " + empID + "\n\t\t|Email : " + empEmail
         + "\n\t\t|Address : " + empAlamat+ "\n\t\t|Date Employed : " + empTarikh + 
         "\n\t\t|Department : " + empDpmt+ "\n\t\t|Status : " + empStat + "\n\t\t|Leave day : " + empLeave;
    }
    
    
       double totSalary = 0;
        public double calSalary(double fullSalary, double allowance,double subLeave)
        
      {
        
        totSalary = fullSalary + allowance - subLeave;
        
        return totSalary;
        }
        
        
        // FULL TIME SALARY FOR DEPARTMENT
        double a = 5500; //administration
        double b = 5000; //accounting
        double c = 4000; //marketing
        double d = 3000; //human resource
        
        //ALLOWANCE BY STATUS
        double v = 1000; //manger
        double w = 800;  //assistant manager
        double x = 500;  //senior
        double y = 200;  //junior
        double z = 100;  //intern
        
        
        //LEAVE DAY WITH SALARY IN A YEAR
        int mld = 21;
        int ald = 17;
        int sld = 14;
        int jld = 7;
        int ild = 3;
        
        
        
        
    /*
     * DEPARTMENT
     * Administration/operations = RM5500
         Marketing and sales  = RM4000 
         Human resources = RM3000
         Accounting and finance = RM5000*/ 
         
        /*STATUS(allowance)
         * intern = 100
         * junior = 200
         * senior = 500
         * assistant manager = 800
         * manager = 1000
         * 
         * 
         * 
         * LEAVE (IF CUTI LEBIH LIMIT,EVERY DAY OF LEAVE WILL BE SUBTRACT FROM BASIC SALARY)
         * intern = LIMIT<3
         * junior = LIMIT<7
         * senior = LIMIT<14
         * assistant manager = LIMIT<21
         * manager = LIMIT<21
         * 
         * 
           
           
           
           
    
    
    
    
}

 
   class Date {  
 
     private int day;  
     private int month;  
     private int year;  

        public Date ( int d,int m,int y) {
    
      
        day = d;
        month = m;
        year = y;

    
      }
   
      public int getDay() {return day;}
      public int getMonth() {return month;}
      public int getYear() {return year;}
     
        public String toString(){
            return day + ", " + month + ", " + year ;
        }
   }


    class Address{

   private String street1;
   private String street2;
   private String postcode;
   private String district; 
   private String state;


      public Address(String st1,String st2,String ps, String ds,String st){

     street1 = st1;
     street2 = st2;
     postcode = ps;
     district = ds;
     state = st;


   }

   public String getStreet1()   {return street1;}
   public String getSteet2 ()   {return street2 ;}
   public String getPostcode () {return postcode;}
   public String getDistrict()  {return district;}
   public String getState()     {return state;}


   public String toString(){
            return  street1 + ", " + street2 + ", " + postcode + ", " + district + ", " + state;
        }
  }*/