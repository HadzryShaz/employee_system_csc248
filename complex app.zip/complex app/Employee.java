
   //CLASS EMPLOYEE
   public class Employee {
    
    private String empName,empEmail,empDpmt,empStat;
    
    private Address empAlamat;
    private Date empTarikh;
    private Double empBasic, empAllow;
    private String empDate;
    private int empLeave,empID ;
    private double fullSalary, allowance, subLeave;
    private long empTotDay;

    
    
    public Employee(int i, String n, String e, String s1, String s2, String pc, String dt, String st, String date, String d, String s, int l,long tot)
    {
        empID = i;
        empName = n;
        empEmail = e;
        empAlamat = new Address(s1,s2,pc,dt,st);
        empDate = date;
        empDpmt = d;
        empStat = s;
        empLeave = l;
        empTotDay = tot;
        
    }
    
    
    public void setEmployee( String n, String e, String s1, String s2, String pc, String dt, String st, String date, String d, String s, int l,long tot)
    {   
        
        empName = n;
        empEmail = e;
        empAlamat = new Address(s1,s2,pc,dt,st);
        empDate = date;
        empDpmt = d;
        empStat = s;
        empLeave = l;
        empTotDay = tot;
        
        
        
    }
    
    public int getID()         { return empID; }
    public String getName()    { return empName; }
    public String getEmail()   { return empEmail; }
    public Address getAlamat() { return empAlamat; }
    public String getDate()    { return empDate; }
    public String getDpmt()    { return empDpmt; }
    public String getStat()    { return empStat; }
    public double getLeave()   { return empLeave; }
    public long getEmpTotDay() { return empTotDay; }
    
    public String toString(){
        return
              "\n\t| Name                                                    : " + empName + 
              "\n\t| ID                                                      : " + empID + 
              "\n\t| Email                                                   : " + empEmail+
              "\n\t| Address                                                 : " + empAlamat+ 
              "\n\t| Date Employed                                           : " + empDate + 
              "\n\t| Department                                              : " + empDpmt+ 
              "\n\t| Status                                                  : " + empStat + 
              "\n\t| Leave day                                               : " + empLeave;
    }
    
    public String toString2(){
        return
              "\n\t| Name                                                    : " + empName + 
              "\n\t| ID                                                      : " + empID + 
              "\n\t| Email                                                   : " + empEmail+
              "\n\t| Department                                              : " + empDpmt+ 
              "\n\t| Status                                                  : " + empStat;
    }
    
       double totSalary = 0;
        public double calSalary(double fullSalary, double allowance,double subLeave)
        
      {
        
        totSalary = fullSalary + allowance - subLeave ;
        
        return totSalary;
        }
        
      
    
    
}

 


    class Address{

   private String street1;
   private String street2;
   private String postcode;
   private String district; 
   private String state;


      public Address(String st1,String st2,String ps, String ds,String st){

     street1 = st1;
     street2 = st2;
     postcode = ps;
     district = ds;
     state = st;


   }

   public String getStreet1()   {return street1;}
   public String getSteet2 ()   {return street2 ;}
   public String getPostcode () {return postcode;}
   public String getDistrict()  {return district;}
   public String getState()     {return state;}


   public String toString(){
            return  street1 + ", " + street2 + ", " + postcode + ", " + district + ", " + state;
        }
  }