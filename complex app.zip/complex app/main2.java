
import java.lang.*;
import java.io.*;
import java.io.IOException;
import java.util.StringTokenizer;
import java.util.*;
import java.time.format.DateTimeFormatter;  
import java.time.LocalDateTime; 
import java.util.Date;
import java.text.ParseException;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.Random;


    public class main2 {
      
        public static void intro (){
        System.out.println("\t|-----------------------------------------------------------------------------------|");
        System.out.println("\t|                                                                                   |");
        System.out.println("\t|           HELLO AND WELCOME TO EMPLOYEE DATA AND INFORMATION SYSTEM               |");
        System.out.println("\t|                                                                                   |");
        System.out.println("\t|-----------------------------------------------------------------------------------|");
      }
    
           //CLEAR SCREEN FUCTION
        public static void clrscr() throws Exception{
        Scanner sc = new Scanner(System.in);
        System.out.println("\t|-----------------------------------------------------------------------------------|");
        System.out.println("\t|                   <<  Enter Any key to Return to Main Menu >>>                    |");
        System.out.println("\t|-----------------------------------------------------------------------------------|");
        sc.nextLine();
        new ProcessBuilder("cmd", "/c", "cls").inheritIO().start().waitFor();
      }
     
           //MAIN MENU OPTION
        public static void mainMenu(){
        System.out.println("\t\t\t\t\t[---------------------------------------------------]");
        System.out.println("\t\t\t\t\t[--------------------1: Store-----------------------]");
        System.out.println("\t\t\t\t\t[---------------2: Search and Edit------------------]");
        System.out.println("\t\t\t\t\t[---------------3: Display Salary-------------------]");
        System.out.println("\t\t\t\t\t[------------4: Display work schedule---------------]");
        System.out.println("\t\t\t\t\t[-------5: Request promotion for employee-----------]");
        System.out.println("\t\t\t\t\t[------------6: Display pending request-------------]");
        System.out.println("\t\t\t\t\t[--------------Please input your choice------------ ]");
        System.out.println("\t\t\t\t\t[---------------------------------------------------]"); 
      }
       
        public static void main(String[]args)throws IOException{
        
        intro();
        System.out.println("\t|--------------------------------Today Date-----------------------------------------|");
        DateTimeFormatter dtf; 
        dtf = DateTimeFormatter.ofPattern("\t|--------------------------------dd/MM/yyyy-----------------------------------------|");  
        LocalDateTime now = LocalDateTime.now();  
        System.out.println(dtf.format(now));
        LocalDate easy = LocalDate.now();
                                                
        Scanner sc = new Scanner(System.in);
            //object array
        LinkedList  dep= new LinkedList();
        ArrayList adm = new ArrayList();
        ArrayList acc = new ArrayList();
        ArrayList mrk = new ArrayList();
        ArrayList hr = new ArrayList();
        
        Queue q = new Queue();
        Queue temp = new Queue();
         
        Random rand = new Random(); //auto generate id
        int rangeID = 999;
         //object counter
        int bilDpmt1 = 0;
        int bilDpmt2 = 0;
        int bilDpmt3 = 0;
        int bilDpmt4 = 0;
         
         //department
        String dpmt1 = "Administration and Management";
        String dpmt2 = "Accounting and Auditing";
        String dpmt3 = "Marketing and Sales";
        String dpmt4 = "Human Resources";
        
        //status
        String stat1 = "Manager";
        String stat2 = "Asisstant Manager";
        String stat3 = "Senior";
        String stat4 = "Junior";
        String stat5 = "Intern";
         
         
        try
      {
             clrscr();
      }
         catch (Exception e)
      {
         e.printStackTrace();
      }
         
           for(;;) {
        
           mainMenu();
           System.out.print("\t| Menu : ");
           int menu = Integer.parseInt(sc.next());
           sc.nextLine();
          
              switch(menu) {
              
              case 1:
                  
              System.out.println("\t|-----------------------------------------------------------------------------------|");
              System.out.println("\t|              THIS MENU IS FOR STORING THE DATA OF A NEW EMPLOYEE                  |");
              System.out.println("\t|-----------------------------------------------------------------------------------|");
              
              int s1 =  rand.nextInt(rangeID);
              System.out.println("\t| The employee new ID is                                             : "+ s1); 
               
              System.out.print("\t| Please enter name                                                  : ");
              String s2 = sc.nextLine();
        
              System.out.print("\t| Please enter Email                                                 : ");
              String s3 = sc.nextLine();
        
              System.out.println("\t| (street1,street2,postcode,district,state)                          |");
              System.out.print("\t| Please enter address (Based on format above)                       : ");
              String s4 = sc.nextLine();
              StringTokenizer token = new StringTokenizer(s4,",");
              String street1 = token.nextToken();
              String street2 = token.nextToken();
              String postcode = token.nextToken();
              String district = token.nextToken();
              String state = token.nextToken();
        
              System.out.print("\t| Please enter date employed (day/month/year)                        : ");
              String s5 = sc.nextLine();
              

              String s6;
              System.out.println("\t| ['1'=admin |'2'=accounting |'3'=marketing |'4'=resources]          |");              
              do{
                 System.out.print("\t| Please enter department                                            : ");
                 int depNum = sc.nextInt();
               
                    if (depNum==1)
                       s6=dpmt1;
                         else if (depNum==2)
                                 s6=dpmt2;
                                  else if (depNum==3)
                                         s6=dpmt3;
                                             else if (depNum==4)
                                                    s6=dpmt4;
                                                      else
                                                         { s6=null;
                                                             System.out.println("\t| Non-existing status!, Please enter again");  }                                
                }while (s6==null);
        
               
              String s7;
              System.out.println("\t| ['1'=manager |'2'=assistant |'3'=senior |'4'junior |'5'=intern ] |");
              do{
                  System.out.print("\t| Please enter status                                                : ");
                   int statNum = sc.nextInt();
                  
                    if (statNum==1)
                         s7 = stat1;
                          else if (statNum==2)
                                 s7 = stat2;
                                  else if (statNum==3)
                                       s7 = stat3;
                                       else if (statNum==4)
                                                s7 = stat4;
                                                 else if (statNum==5)
                                                          s7 = stat5;
                                                          else
                                                               {s7 = null;
                                                               System.out.println("\t| Non-existing status!, Please enter again");}
                }while (s7==null);
                                                            
               int dey = easy.lengthOfMonth();
               int s8 = -1;
               do {
                  System.out.print("\t| Please enter total leave                                           : ");
                  int leaveNum = sc.nextInt();
                  if (leaveNum<=dey)
                       s8 = leaveNum;
                         else
                             {s8 =0;
                              System.out.println("\t| Thats over a month!, Please enter again");}
                 } while (s8==-1);       
              
            
                
                  DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
                  LocalDate firstDate = LocalDate.parse(s5, formatter);
                  LocalDate secondDate = LocalDate.now();
                  long days = ChronoUnit.DAYS.between(firstDate, secondDate);
                 
                 
               Employee emp = new Employee(s1,s2,s3,street1,street2,postcode,district,state,s5,s6,s7,s8,days);
               dep.insertAtBack(emp);
               
               Employee obj = dep.getFirst();
              
               while(obj!=null){
        
                 if (emp.getDpmt().equals(dpmt1)){
                    adm.add(obj);
                    bilDpmt1++;
                    obj = dep.getNext();
                   }
                    else if (emp.getDpmt().equals(dpmt2)){ 
                             acc.add(obj);
                              bilDpmt2++;
                             obj = dep.getNext();
                           }
                            else if (emp.getDpmt().equals(dpmt3)){ 
                                    mrk.add(obj);
                                     bilDpmt3++;
                                    obj = dep.getNext();
                                   }
                                    else
                                         bilDpmt4++;
                                        hr.add(obj); 
                  obj = dep.getNext();
              }
        
                  try
               {
                 clrscr();
               }
                 catch (Exception e)
               {
                 e.printStackTrace();
               }
        
              break;
                 
            
        
              case 2:
           
            {
               int searchID;
               System.out.println("\t|-----------------------------------------------------------------------------------|");
               System.out.println("\t|                 THIS MENU IS FOR SEARCHING THE DATA OF A EMPLOYEE                 |");
               System.out.println("\t|-----------------------------------------------------------------------------------|");
               
               obj = dep.getFirst();
               int kira = 1;
               
                  while(obj!=null){
                       System.out.println("\t| "+ kira + "/ " + obj.getName() + "\t| :" + obj.getID() + "\n");
                
                       obj = dep.getNext();
                       kira++;
                 }
    
               System.out.print("\t| Please enter ID                                                    : ");
               searchID = sc.nextInt();
               boolean found = false;
             
               obj = dep.getFirst();
             
               while(obj!=null){
                    try{
                        if (obj.getID()==searchID){
                           found = true;
                           System.out.println(obj.toString());
                       System.out.println("\t| total days of work from start employed                  : " + obj.getEmpTotDay() + " days");
                        
                           dey = easy.lengthOfMonth();
                           int totMonth = dey - (int)Math.round(obj.getLeave());
                           System.out.println("\t| total days of work in this month                        : " + totMonth + " days");
                        
                           System.out.print("\t| Do You want to edit this employee Data ['Y'=YES|'N'=NO] : ");
                           char tentu = sc.next().charAt(0);
                           sc.nextLine();
                          
                           if (tentu=='y'||tentu=='Y') {
                              System.out.print("\t|--------------------------------------------------------------------|");
                              System.out.print("\n\t| Please enter name                                                  : ");
                              s2 = sc.nextLine();
        
                              System.out.print("\t| Please enter Email                                                 : ");
                              s3 = sc.nextLine();
        
                              System.out.println("\t| (street1,street2,postcode,district,state)                          |");
                              System.out.print("\t| Please enter address (Based on format above)                       : ");
                              s4 = sc.nextLine();
                              token = new StringTokenizer(s4,",");
                              street1 = token.nextToken();
                              street2 = token.nextToken();
                              postcode = token.nextToken();
                              district = token.nextToken();
                              state = token.nextToken();
        
                              System.out.print("\t| Please enter date employed (day/month/year)                        : ");
                              s5 = sc.nextLine();
                           
                              System.out.println("\t| ['1'=admin |'2'=accounting | '3'=marketing | '4'=resources ]   |");
                              do{  
                                  System.out.print("\t| Please enter department                                            : ");
                                  int depNum = sc.nextInt();
                                  if (depNum==1)
                                    s6 = dpmt1;
                                     else if (depNum==2)
                                            s6 = dpmt2;
                                            else if (depNum==3)
                                                    s6 = dpmt3;
                                                     else if (depNum==4)
                                                             s6 = dpmt4;
                                                                 else
                                                                    { s6=null;
                                                                      System.out.println("\t| Non-existing status!, Please enter again");  }                                
                                 }while (s6==null); 

                               System.out.println("\t| ['1'=manager |'2'=assistant | '3'=senior | '4'junior | '5'=intern ]| ");
                               do {
                                   System.out.print("\t| Please enter status                                                : ");
                                   int statNum = sc.nextInt();
                                   
                                   if (statNum==1)
                                     s7 = stat1;
                                      else if (statNum==2)
                                              s7 = stat2;
                                             else if (statNum==3)
                                                     s7 = stat3;
                                                     else if (statNum==4)
                                                             s7 = stat4;
                                                            else if (statNum==5)
                                                                   s7 =stat5;
                                                                    else
                                                                    {s7 =null;
                                                                     System.out.println("\t| Non-existing status!, Please enter again");}
                               }while (s7==null);
                          
                                                            
                               dey = easy.lengthOfMonth();
                               s8 = -1;
                               do {
                                    System.out.print("\t| Please enter total leave                                           : ");
                                    int leaveNum = sc.nextInt();
                                    if (leaveNum<=dey)
                                        s8 = leaveNum;
                                      else
                                         {s8 =0;
                               System.out.println("\t| Thats over a month!, Please enter again");}
                                   } while (s8==-1);   

                                formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
                                firstDate = LocalDate.parse(s5, formatter);
                                secondDate = LocalDate.now();
                                days = ChronoUnit.DAYS.between(firstDate, secondDate);
                                obj.setEmployee(s2,s3,street1,street2,postcode,district,state,s5,s6,s7,s8,days);
                               emp = obj;
                             obj = dep.getNext();

                        }
                        else                         
                        obj = dep.getNext();
                }
                else obj = dep.getNext();
            }    
            catch (NullPointerException e)
            {
                break;
            }
         }
        
                 if(!found)
            {      System.out.println("\t|-----------------------------------------------------------------------------------|");
                   System.out.println("\t|                           Sorry, employee not found!                              |");
                   System.out.println("\t|-----------------------------------------------------------------------------------|");   
            }                        
            }
           
                   try
             {
                 clrscr();
             }
             catch (Exception e)
             {
                 e.printStackTrace();
             }
             
            
             break;
            
             case 3:
              
        {    System.out.println("\t|-----------------------------------------------------------------------------------|");
             System.out.println("\t|               THIS MENU IS FOR DISPLAY THE TOTAL SALARY OF A EMPLOYEE             |");
             System.out.println("\t|-----------------------------------------------------------------------------------|");
               
               System.out.print("\t| Please enter ID            : ");
               int searchID = sc.nextInt();
         
             obj = dep.getFirst();
             boolean found2 = false;
                 
             while(obj!=null){
                 if (obj.getID()==searchID)
               {    found2 = true;
                    double sal = 0;
                {  if (obj.getStat().equals(stat1))
                       sal = 5000; //administration
                          else if (obj.getStat().equals(stat2))
                                 sal = 4500; //accounting
                                   else if (obj.getStat().equals(stat3))
                                           sal = 3500; //marketing
                                          else if (obj.getStat().equals(stat4))
                                                 sal = 2000;
                                                  else if (obj.getStat().equals(stat5))
                                                         sal = 1000;
                                                         else 
                                                           sal = 0;//human resource
                     }                           
                    double all = 0;
               {    if (obj.getDpmt().equals(dpmt1))
                       all = 1000; //manager
                        else if (obj.getDpmt().equals(dpmt2))
                                all = 800; //assistant manager
                                else if (obj.getDpmt().equals(dpmt3))
                                       all = 600; //senior
                                       else if (obj.getDpmt().equals(dpmt4))
                                               all = 400; //junior
                                               else
                                                all = 0;
                   }                              
                    double lve = 0;
               {    if (obj.getStat().equals(stat1)&&obj.getLeave()>7)
                        lve = obj.getLeave()-7;  
                        else if (obj.getStat().equals(stat2)&&obj.getLeave()>5)
                                 lve = obj.getLeave()-5; 
                                  else if (obj.getStat().equals(stat3)&&obj.getLeave()>5)
                                            lve = obj.getLeave()-5; 
                                          else if (obj.getStat().equals(stat4)&&obj.getLeave()>3)
                                                    lve = obj.getLeave()-3;
                                                    else if (obj.getStat().equals(stat5)&&obj.getLeave()>2)
                                                             lve = obj.getLeave()-2;                                         
                    } 
                    
               dey = easy.lengthOfMonth();                    
               double newLve = (lve/dey)*sal; 
               double totLve = Math.round(newLve);
               double totSalary = obj.calSalary(sal,all,totLve);
               System.out.println("\t| Employee Name              : " + obj.getName());
               System.out.println("\t| Monthly Salary             : " + sal);
               System.out.println("\t| Monthly allowance          : " + all);
               System.out.println("\t| Minus ( Unpaid Leave )     : " + newLve);
               System.out.println("\t|----------------------------|------------------------------------------------------|");
               System.out.println("\t| Total this employee salary : " + totSalary);
               
               break;
            }
            
            else 
                obj = dep.getNext();    
          }
        
                  if(!found2)
            {      System.out.println("\t|-----------------------------------------------------------------------------------|");
                   System.out.println("\t|                           Sorry, employee not found!                              |");
                   System.out.println("\t|-----------------------------------------------------------------------------------|");   
            }                 
            
                   
                   try
             {
                 clrscr();
             }
             catch (Exception e)
             {
                 e.printStackTrace();
             }
             
                   break;
        }
        
               case 4:
            
                   
          {
               System.out.println("\t|-----------------------------------------------------------------------------------|");
               System.out.println("\t|                    THIS MENU IS FOR DISPLAY EMPLOYEE WORK SCEDULE                 |");
               System.out.println("\t|-----------------------------------------------------------------------------------|");
               String searchID2;
               System.out.print("\t| Please enter ID : ");
               int searchID = sc.nextInt();
               
               obj = dep.getFirst();
               boolean found2 = false;
            
               while(obj!=null){
                   if (obj.getID()==searchID)
                {      found2= true ;
                       String shift;
                 {    if (obj.getStat().equals(stat1))
                          shift = "night"; 
                          else if (obj.getStat().equals(stat2))
                                   shift = "morning";
                                  else if (obj.getStat().equals(stat3))
                                           shift = "night";
                                           else if (obj.getStat().equals(stat4))
                                                   shift = "morning";
                                                     else if (obj.getStat().equals(stat5))
                                                              shift = "morning";
                                                               else
                                                                 shift = "you are not from this company";                                     
                   } 
                       String dayWork;
                 {    if (obj.getDpmt().equals(dpmt1))
                          dayWork = "Monday, Wednesday, Friday, Saturday";  
                          else if (obj.getDpmt().equals(dpmt2))
                                 dayWork = "Monday, Tuesday, Thursday, Saturday";
                                  else if (obj.getDpmt().equals(dpmt3))
                                           dayWork = "Monday, Tuesday, Friday";
                                          else if (obj.getDpmt().equals(dpmt4))
                                                   dayWork = "Monday, Tuesday, Wednesday, Thursday";
                                                    else
                                                     dayWork = "you are not from this company";                                     
                                    } 
                      System.out.println("\t| Your shift is : " + shift);
                      System.out.println("\t| Your shift is : " + dayWork);
                      break ;
           }
             else
                 obj = dep.getNext();
        }    
                      if(!found2)
            {      System.out.println("\t|-----------------------------------------------------------------------------------|");
                   System.out.println("\t|                           Sorry, employee not found!                              |");
                   System.out.println("\t|-----------------------------------------------------------------------------------|");   
            }                 
            
            
                  try
             {
                 clrscr();
             }
             catch (Exception e)
             {
                 e.printStackTrace();
             }
             break;
      }    
            
          case 5:

             {
                try{
                System.out.println("\t|-----------------------------------------------------------------------------------|");
                System.out.println("\t|                 THIS MENU IS FOR REQUEST A PROMOTION FOR EMPLOYEE                 |");
                System.out.println("\t|-----------------------------------------------------------------------------------|");
                System.out.print("\t| Please enter your ID : ");
                int searchID = sc.nextInt();

                obj = dep.getFirst();
                boolean found3 = false;

                while(obj!=null){
                    if(obj.getID()==searchID){
                        found3 = true;
                        q.enqueue(obj);
                        System.out.println("\t| Request has been submitted");
                        obj = dep.getNext();
                    }
                    else
                        obj = dep.getNext();
                }

                          if(!found3)
                    {      System.out.println("\t|-----------------------------------------------------------------------------------|");
                           System.out.println("\t|                Sorry, there are no matching employee data!                        |");
                           System.out.println("\t|-----------------------------------------------------------------------------------|");   
                   }                  
                  }    
                   catch (NullPointerException e)
                  {  break;
                  }
              

                try
                {
                    clrscr();
                }
                catch (Exception e)
                {
                    e.printStackTrace();
                }
                
                    break;
            }
        

             case 6:

             {  try{
                System.out.println("\t|-----------------------------------------------------------------------------------|");
                System.out.println("\t|               THIS MENU IS FOR DISPLAY ALL PENDING PROMOTION REQUEST              |");
                System.out.println("\t|-----------------------------------------------------------------------------------|");
                obj = dep.getFirst();
                
                if(!q.isEmpty()){
                while(!q.isEmpty()){
                    obj = (Employee) q.dequeue();

                    System.out.println(obj.toString2());

                    temp.enqueue(obj);
                }
            }   
                 else{
                       System.out.println("\t|-----------------------------------------------------------------------------------|");
                       System.out.println("\t|                Sorry, there are no matching employee data!                        |");
                       System.out.println("\t|-----------------------------------------------------------------------------------|");  
                     
                       try
                      {
                        clrscr();
                      }
                         catch (Exception e)
                      {
                         e.printStackTrace();
                      }
                      break; 
                     
                 }

                System.out.println("/t| Current Request:-");
                obj = (Employee) temp.getFront();

                System.out.println(obj.toString2());

                System.out.println("/t| Request reviewed? ('Y' for Yes | 'N' for No");
                char rr = sc.nextLine().charAt(0);

                if(rr == 'Y' || rr == 'y'){
                    System.out.println("\t| Request has been viewed, Please check your email for further information");

                    temp.dequeue();
                }

                while(!temp.isEmpty()){
                    obj = (Employee) temp.dequeue();

                    q.enqueue(obj);
                }

                try
                {
                    clrscr();
                }
                catch (Exception e)
                {
                    e.printStackTrace();
                }
             
              }    
            catch (NullPointerException e)
            {  break;
            }

    }     
  }
}                   //Letak exception msa search data n masa display pending request
                    //Bt if data x jumpe bt loop
}
}
      
      
      
      
      
      
      
      
      

          
        
                  
