/*
import java.lang.*;
import java.io.*;
import java.io.IOException;
import java.util.StringTokenizer;
import java.util.*;
import java.time.format.DateTimeFormatter;  
import java.time.LocalDateTime; 
import java.time.*;

  public class main {
       public static void intro (){
        System.out.println("\t\t|----------------------------------------------------------------------------|");
        System.out.println("\t\t|                                                                            |");
        System.out.println("\t\t|     HELLO AND WELCOME TO EMPLOYEE DATA AND INFORMATION SYSTEM              |");
        System.out.println("\t\t|                                                                            |");
        System.out.println("\t\t|----------------------------------------------------------------------------|");
    }
       
      //CLEAR SCREEN FUCTION
     public static void clrscr() throws Exception{
     Scanner sc = new Scanner(System.in);

        System.out.println("\t\t|----------------------------------------------------------------------------|");
        System.out.println("\n\t\t|            <<<  Enter any key to return to Main Menu >>>                 |");
        System.out.println("\t\t|----------------------------------------------------------------------------|");
        sc.nextLine();

     new ProcessBuilder("cmd", "/c", "cls").inheritIO().start().waitFor();
       }
     
       //MAIN MENU OPTION
         public static void mainMenu(){
        
        System.out.println("\t\t\t\t\t[---------------------------------------------------]");
        System.out.println("\t\t\t\t\t[--------------------1: Store-----------------------]");
        System.out.println("\t\t\t\t\t[--------------------2: Search----------------------]");
        System.out.println("\t\t\t\t\t[--------------------3: Edit------------------------]");
        System.out.println("\t\t\t\t\t[--------------------4: Display---------------------]");
        System.out.println("\t\t\t\t\t[--------------Please input your choice------------ ]");
        System.out.println("\t\t\t\t\t[---------------------------------------------------]");
        
      }
       
      
      public static void main(String[]args)throws Exception
    {   
          intro();
          System.out.println("\t\t\t\t\t[------------------------------------------------]");
          
           
          System.out.println("\t\t\t\t\t[---------------------------------------------------]");
         
         Scanner sc = new Scanner(System.in);
         //object array
         LinkedList  dep= new LinkedList();
         ArrayList adm = new ArrayList();
         ArrayList acc = new ArrayList();
         ArrayList mrk = new ArrayList();
         ArrayList hr = new ArrayList();
         
         
         //the object
         //object counter
         int bilAdm = 0;
         int bilMrk = 0;
         int bilDHr = 0;
         int bilAcc = 0;
         
         clrscr();
          for(;;)
         
        
      {
          mainMenu();
          
          System.out.print("\t\t|Menu : ");
          int menu = Integer.parseInt(sc.next());
          sc.nextLine();
          
          switch(menu)
              
        
          
            
              {  
              case 1:
                  
              System.out.println("\t\t|-----------------------------------------------------------------|");
               System.out.println("\t\t|   THIS MENU IS FOR STORING THE DATA OF A NEW EMPLOYEE           |");
               System.out.println("\t\t|-----------------------------------------------------------------|");
        
               System.out.print("\t\t| Please enter name : ");
               String s1 = sc.nextLine();
        
               System.out.print("\t\t| Please enter ID : ");
               String s2 = sc.nextLine();
        
               System.out.print("\t\t| Please enter Email : ");
               String s3 = sc.nextLine();
        
               System.out.print("\t\t| Please enter address (street1,street2,postcode,district,state) : ");
               String s4 = sc.nextLine();
               StringTokenizer token = new StringTokenizer(s4,",");
               String street1 = token.nextToken();
               String street2 = token.nextToken();
               String postcode = token.nextToken();
               String district = token.nextToken();
               String state = token.nextToken();
        
               System.out.print("\t\t| Please enter date employed (day/month/year) : ");
               String s5 = sc.next();
               token = new StringTokenizer(s5,"/");
               String days =  token.nextToken();
               int day = Integer.parseInt(days);
               String months = token.nextToken();
               int month = Integer.parseInt(months);
               String years = token.nextToken();
               int year = Integer.parseInt(years);
               sc.nextLine();

               System.out.print("\t\t| Please enter department : ");
               String s6 = sc.nextLine();
        
               System.out.print("\t\t| Please enter status : ");
               String s7 = sc.nextLine();
            
               System.out.print("\t\t| Please enter total leave : ");
               String luv = sc.nextLine();
               int s8 = Integer.parseInt(luv);
            
               Employee emp = new Employee(s1,s2,s3,street1,street2,postcode,district,state,day,month,year,s6,s7,s8);
               dep.insertAtBack(emp);
               
               Employee obj = dep.getFirst();
               
               
               
               /*while(true){
               try {
               DateTimeFormatter dtf = DateTimeFormatter.ofPattern("\t\t\t\tdd/MM/yyyy");  
               LocalDateTime now = LocalDateTime.now();  
               token = new StringTokenizer(dtf.format(now),"/");
               String curDay =  token.nextToken();
               int curDays= Integer.parseInt(curDay);
               String curMonth = token.nextToken();
               int curMonths = Integer.parseInt(curMonth);
               String curYear = token.nextToken();
               int curYears = Integer.parseInt(curYear);
               
                System.out.println(curDays);
                System.out.println(curMonths);
                System.out.println(curYears);
                
                if (obj.getTarikh().getDay()<curDays)
               break;
            } catch (NumberFormatException e){ }
        }
                                       
               
               while(obj!=null){
        
                
             
              if (emp.getDpmt().equalsIgnoreCase("admin")){
                  adm.add(obj);
                  obj = dep.getNext();
                 }
            
                  else if (emp.getDpmt().equalsIgnoreCase("accounting")){ 
                           acc.add(obj);
                           obj = dep.getNext();
                        }
                         else if (emp.getDpmt().equalsIgnoreCase("marketing")){ 
                                 mrk.add(obj);
                                 obj = dep.getNext();
                               }
                                 else
                                     hr.add(obj); 
                                     obj = dep.getNext();
               
            }
        
            
                
                
          
               break;
                 
            
           
        
        
        
           case 2:
           
             {
             String searchID;
             System.out.println("\t\t|-----------------------------------------------------------------|");
             System.out.println("\t\t|   THIS MENU IS FOR SEARCHING THE DATA OF A EMPLOYEE             |");
             System.out.println("\t\t|-----------------------------------------------------------------|");
             
             System.out.print("\t\t| Please enter ID : ");
             searchID = sc.nextLine();
         
             boolean found = false;
             
             obj = dep.getFirst();
             
             while(obj!=null){
                 try{
             if (obj.getID().equals(searchID)){
                 found = true;
                  System.out.println(obj.toString());
                  
                   LocalDate today = LocalDate.now();
             int currentDay= today.getDayOfMonth();
             int currentMonth= today.getMonthValue();
             int currentYear= today.getYear();
               
                
            int totDay=0;
            if (obj.getTarikh().getDay()<currentDay)
                totDay = currentDay-obj.getTarikh().getDay();
                else if (obj.getTarikh().getDay()>currentDay)
                         totDay = obj.getTarikh().getDay()-currentDay;
               else 
                    totDay = 0;

            int totMonth=0;
            
            if (obj.getTarikh().getMonth()<currentMonth)
                totMonth = currentMonth-obj.getTarikh().getMonth();
                else if (obj.getTarikh().getMonth()>currentMonth)
                         totMonth = obj.getTarikh().getDay()-currentMonth;
               else 
                   totMonth = 0;
                   
            int totYear=0;
            
            if (obj.getTarikh().getYear()<currentYear)
                totYear = currentYear-obj.getTarikh().getYear();
                else if (obj.getTarikh().getYear()>currentYear)
                         totYear = obj.getTarikh().getYear()-currentYear;
               else 
                   totYear = 0;
                   
                System.out.println("Total date of this employee work");  
                System.out.println("\t\t| Days :" + totDay + "Month :" + totMonth + "Year :" + totYear );
               
                
                  obj = dep.getNext();
                }
                else obj = dep.getNext();
            }    
            catch (NullPointerException e)
            {
                break;
            }
        }
            if(!found)
            {
                     System.out.println("\t\t|                 Sorry, employee not found!                   |");
                     System.out.println("\t\t|-----------------------------------------------------------------|");
                     
            }                 
        }
            
             break;
            
            case 3:
              
           {System.out.println("\t\t|-----------------------------------------------------------------|");
            System.out.println("\t\t|   THIS MENU IS FOR DISPLAY THE TOTAL SALARY OF A EMPLOYEE       |");
            System.out.println("\t\t|-----------------------------------------------------------------|");
            String searchID2;
            System.out.print("\t\t| Please enter ID : ");
            searchID2 = sc.nextLine();
         
                 obj = dep.getFirst();
              if (obj.getID().equals(searchID2))
             {
               double sal = 0;
               {if (obj.getDpmt().equals("admin"))
                    sal = 5500; //administration
                    else if (obj.getDpmt().equals("account"))
                             sal = 5000; //accounting
                             else if (obj.getDpmt().equals("marketing"))
                                     sal = 4000; //marketing
                                     else 
                                         sal = 3000; //human resource
                                            }                           
               double all = 0;
               {if (obj.getStat().equals("manager"))
                     all = 1000; //manager
                    else if (obj.getStat().equals("assistant"))
                            all = 800; //assistant manager
                            else if (obj.getStat().equals("senior"))
                                    all = 500; //senior
                                    else if (obj.getStat().equals("junior"))
                                     all = 3000; //junior
                                            else 
                                                all = 100;
                                            }                              
                 double lve = 0;
               {if (obj.getLeave()<=21)
                   lve = 21; //manager
                   else if (obj.getLeave()<=17)
                          lve = 17; //assitant manager
                          else if (obj.getLeave()<=14)
                                 lve = 14;//senior
                                 else if (obj.getLeave()<=7)
                                        lve = 14;//senior
                                        else 
                                            lve = 14;//senior
                                    }                            
               double totSalary = obj.calSalary(sal,all,lve);
               System.out.println("\t\t| Employee Name : " + obj.getName());
               System.out.println("\t\t| Monthly Salary : " + sal);
               System.out.println("\t\t| Monthly allowance : " + all);
               System.out.println("\t\t| Total this employee salary : " + totSalary);
        }
            else System.out.println("\t\t There no employee");                
                   break;
        }
        
        } 
        } 
         
    }
}

*/
          
        
                  
    