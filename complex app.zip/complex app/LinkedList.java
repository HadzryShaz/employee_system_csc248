     // class
     //CLASS LISTNODE
     class ListNode
    {
     Employee data;
     ListNode next;
     ListNode ( Employee obj )
    { this( obj , null ); }
    
    ListNode ( Employee obj , ListNode nextNode)
    { data = obj ;
      next = nextNode ;
      
     }   
     Employee getObject() { return data; }
     
        ListNode getNext() { return next;
   }
  }





    public class LinkedList{
        
    private ListNode firstNode;
    private ListNode lastNode;
    private ListNode currNode ; 
    private String name;

    public LinkedList () // default constructor
    {
        this( "list" ); }

    public LinkedList (String s)// normal constructor
    {
        name = s;
        firstNode
        = lastNode = currNode = null;
    }


    public boolean isEmpty()
    {
        return (
        firstNode == null);
    }


    public void insertAtFront (Employee insertItem)
    {
    if  (isEmpty ())
    firstNode = lastNode = new ListNode (insertItem);
    else
    firstNode = new ListNode (insertItem,firstNode);
   }


    public Employee getFirst()
    {
           if ( isEmpty())
           return null;
           else
    {
        currNode = firstNode;
        return currNode.data ;
        }
    }


    public Employee getLast()
    {
          if ( isEmpty())
          return null;
          else
        {
        currNode = lastNode;
        return currNode.data ;

    }
    }


    public Employee getNext()
    {
        if ( currNode != lastNode)
    {
        currNode = currNode.next;
        return
    currNode.data ;
    }
   else
   return null;
  }


    public void
    insertAtBack ( Employee insertItem)
    {
    if ( isEmpty ())
      firstNode = lastNode = new ListNode (insertItem);
    else
       lastNode
    = lastNode.next = new ListNode (insertItem);
    }


    public Employee removeFromFront ()throws EmptyListException
    {
        
      Employee removeItem = null;
        if ( isEmpty ())
           throw new EmptyListException (name);
        removeItem = firstNode.data ;
        if ( firstNode.equals (lastNode))
         firstNode = lastNode =null;
        else
        firstNode = firstNode.next;
          return removeItem ;
    }


    public Employee removeFromBack ( )throws EmptyListException
    {
    Employee removeItem = null;
    if ( isEmpty () )
    throw new EmptyListException (name);
    removeItem = lastNode.data ;
    if (
    firstNode.equals ( lastNode ))
    firstNode = lastNode = null;
    else
    {
    ListNode current = firstNode;
    while ( current.next != lastNode )
    current = current.next ;
    lastNode = current.next = null;
    }
    return removeItem;
    }
}

     class EmptyListException extends RuntimeException
{
    public EmptyListException( String name)
    {
        super("The" + name + "is empty");
    }
 }

    class Queue extends LinkedList{  
        
        public Queue() { } // constructor
        
        public void enqueue ( Employee elem)
           { insertAtBack (elem);  };
        
        public Employee dequeue ()
        {  return removeFromFront ();  }
        
        public Employee getFront ()
         { return getFirst (); }
             
        public Employee getEnd ()
        {  return getLast(); }
} // end Queue
